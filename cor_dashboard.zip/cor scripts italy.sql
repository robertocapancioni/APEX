CREATE OR REPLACE FORCE EDITIONABLE VIEW  "COR_STAT_ITALY_HIST" ("DATA", "STATO", "CODICE_REGIONE", "DENOMINAZIONE_REGIONE", "LAT", "LON", "RICOVERATI_CON_SINTOMI", "TERAPIA_INTENSIVA", "TOTALE_OSPEDALIZZATI", "ISOLAMENTO_DOMICILIARE", "TOTALE_ATTUALMENTE_POSITIVI", "NUOVI_ATTUALMENTE_POSITIVI", "DIMESSI_GUARITI", "DECEDUTI", "TOTALE_CASI", "TAMPONI", "LATEST") DEFAULT COLLATION "USING_NLS_COMP"  AS 
  SELECT to_date(DATA,'yyyy-mm-dd hh24:mi:ss')DATA,STATO,CODICE_REGIONE,DENOMINAZIONE_REGIONE,LAT,LON,RICOVERATI_CON_SINTOMI,TERAPIA_INTENSIVA,TOTALE_OSPEDALIZZATI,ISOLAMENTO_DOMICILIARE,TOTALE_ATTUALMENTE_POSITIVI,NUOVI_ATTUALMENTE_POSITIVI,DIMESSI_GUARITI,DECEDUTI,TOTALE_CASI,TAMPONI, 
decode(rank() over (order by data desc),1,1,0) latest 
FROM json_table(apex_web_service.make_rest_request(p_url => 'https://raw.githubusercontent.com/pcm-dpc/COVID-19/master/dati-json/dpc-covid19-ita-regioni.json',p_http_method => 'GET'), 
                         '$[*]' columns( 
                             data varchar2(20)  path'$.data', 
                             stato varchar2(10) path'$.stato', 
                             codice_regione varchar2(3) path'$.codice_regione', 
                             denominazione_regione varchar2(50) path'$.denominazione_regione', 
                             lat number path'$.lat', 
                             lon number path'$.long', 
                             ricoverati_con_sintomi int path'$.ricoverati_con_sintomi', 
                             terapia_intensiva int path'$.terapia_intensiva', 
                             totale_ospedalizzati int path'$.totale_ospedalizzati', 
                             isolamento_domiciliare int path'$.isolamento_domiciliare', 
                             totale_attualmente_positivi int path'$.totale_attualmente_positivi', 
                             nuovi_attualmente_positivi int path'$.nuovi_attualmente_positivi', 
                             dimessi_guariti int path'$.dimessi_guariti', 
                             deceduti int path'$.deceduti', 
                             totale_casi int path'$.totale_casi', 
                             tamponi int path'$.tamponi'))a 
                             where data like '2%'
/